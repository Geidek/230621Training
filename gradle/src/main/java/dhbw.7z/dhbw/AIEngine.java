package dhbw;

public class AIEngine {


    Austauschbare AIEngine in 2 Ausführungen (2048/4096 GPU, Komposition)
}
