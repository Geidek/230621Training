package dhbw;

public class Wheel {
}
